ALVIRA Connect browser extension MVP

1. Unzip this folder.
2. Open chrome://extensions in a Chromium browser.
3. Enable Developer mode.
4. Click Load unpacked and choose the unzipped folder.
5. In ALVIRA, open Use elsewhere and copy a reviewed Context View.
6. Open ALVIRA Connect, paste the Context View, and save it.
7. Visit ChatGPT, Claude, Gemini, or Perplexity.
8. Click inside the prompt box, then click Use ALVIRA Context.

The extension inserts context but never sends the prompt.
It stores the reviewed Context only in chrome.storage.local.
It does not read conversation history, cookies, passwords, or account credentials.

This is a preview build for QA. Store distribution should be used for production.
